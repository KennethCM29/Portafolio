<?php
/**
 * Plugin Name: Prueba 9
 * Description: A WordPress plugin to manage GPT queries and display responses in a widget.
 * Version: 1.0
 * Author: Your Name
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Activation hook
register_activation_hook(__FILE__, 'widgetgpt_activate');
function widgetgpt_activate() {
    // Initialize options
    if (!get_option('widgetgpt_entries')) {
        update_option('widgetgpt_entries', array());
    }
    if (!get_option('widgetgpt_responses')) {
        update_option('widgetgpt_responses', array());
    }
    if (!get_option('widgetgpt_selected')) {
        update_option('widgetgpt_selected', '');
    }
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'widgetgpt_deactivate');
function widgetgpt_deactivate() {
    // Optional cleanup
}

// Add admin menu
add_action('admin_menu', 'widgetgpt_add_admin_menu');
function widgetgpt_add_admin_menu() {
    add_menu_page(
        'WidgetGPT',
        'WidgetGPT',
        'manage_options',
        'widgetgpt',
        'widgetgpt_admin_page',
        'dashicons-admin-generic',
        30
    );
}

// Admin page
function widgetgpt_admin_page() {
    if (isset($_POST['submit'])) {
        $title = sanitize_text_field($_POST['title']);
        $query = sanitize_textarea_field($_POST['query']);
        $api_key = sanitize_text_field($_POST['api_key']);

        $entries = get_option('widgetgpt_entries', array());
        $entries[] = array(
            'title' => $title,
            'query' => $query,
            'api_key' => $api_key
        );
        update_option('widgetgpt_entries', $entries);
        echo '<div class="notice notice-success"><p>Entry added successfully!</p></div>';
    }

    if (isset($_POST['delete_all'])) {
        update_option('widgetgpt_entries', array());
        update_option('widgetgpt_responses', array());
    echo '<div class="notice notice-success"><p>Todo ha sido borrado</p></div>';
    }

    if (isset($_POST['edit'])) {
        $edit_id = intval($_POST['edit_id']);
        $edit_field = sanitize_text_field($_POST['edit_field']);
        $edit_value = sanitize_text_field($_POST['edit_value']);

        $entries = get_option('widgetgpt_entries', array());
        foreach ($entries as $key => &$entry) {
            $current_id = $key + 1;
            if ($current_id == $edit_id) {
                $entry[$edit_field] = $edit_value;
                break;
            }
        }
        update_option('widgetgpt_entries', $entries);
        echo '<div class="notice notice-success"><p>¡Editado!</p></div>';
    }

    if (isset($_POST['select_response'])) {
        $selected_title = sanitize_text_field($_POST['selected_title']);
        $selected_response = sanitize_text_field($_POST['selected_response']);
        update_option('widgetgpt_selected', array('title' => $selected_title, 'response' => $selected_response));
    echo '<div class="notice notice-success"><p>¡Respuesta seleccionada!</p></div>';
    }

    if (isset($_POST['delete_entry'])) {
        $delete_id = intval($_POST['delete_id']);
        $entries = get_option('widgetgpt_entries', array());
        $responses = get_option('widgetgpt_responses', array());
        $selected = get_option('widgetgpt_selected', array());

        // Find the entry to delete
        $entry_to_delete = null;
        foreach ($entries as $key => $entry) {
            $current_id = $key + 1;
            if ($current_id == $delete_id) {
                $entry_to_delete = $entry;
                unset($entries[$key]);
                break;
            }
        }

        if ($entry_to_delete) {
            // Remove related responses
            foreach ($responses as $key => $response) {
                if ($response['title'] == $entry_to_delete['title'] && $response['query'] == $entry_to_delete['query']) {
                    unset($responses[$key]);
                }
            }

            // Reindex arrays
            $entries = array_values($entries);
            $responses = array_values($responses);

            // Check if selected response is deleted
            if ($selected && is_array($selected)) {
                $found = false;
                foreach ($responses as $response) {
                    if ($response['title'] == $selected['title'] && $response['response'] == $selected['response']) {
                        $found = true;
                        break;
                    }
                }
                if (!$found) {
                    update_option('widgetgpt_selected', '');
                }
            }

            update_option('widgetgpt_entries', $entries);
            update_option('widgetgpt_responses', $responses);
            echo '<div class="notice notice-success"><p>¡La entrada ha sido borrada con éxito!</p></div>';
        }
    }

    if (isset($_POST['delete_response'])) {
        $delete_title = sanitize_text_field($_POST['delete_title']);
        $delete_query = sanitize_text_field($_POST['delete_query']);
        $delete_response_text = sanitize_text_field($_POST['delete_response_text']);
        $responses = get_option('widgetgpt_responses', array());
        $selected = get_option('widgetgpt_selected', array());

        // Remove the specific response
        foreach ($responses as $key => $response) {
            if ($response['title'] == $delete_title && $response['query'] == $delete_query && $response['response'] == $delete_response_text) {
                unset($responses[$key]);
                break;
            }
        }

        // Reindex array
        $responses = array_values($responses);

        // Check if selected response is deleted
        if ($selected && is_array($selected)) {
            if ($selected['title'] == $delete_title && $selected['response'] == $delete_response_text) {
                update_option('widgetgpt_selected', '');
            }
        }

        update_option('widgetgpt_responses', $responses);
        echo '<div class="notice notice-success"><p>¡Respuesta borrada correctamente!</p></div>';
    }

    ?>

    <style>
        h1, h2{
            color: white;
        }
        .wrap {
            background: linear-gradient(to bottom, #0051ffff, #00e1ffff);
        }
        .form-table th {
            color: white;
        }
        .add-button {
            background: white;
            color: blue;
            border: 1px solid #ccc;
        }
        .add-button:hover {
            background: #f0f0f0;
        }
    </style>
 
    <div class="wrap">
        <h1>WidgetGPT</h1>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th>Titulo</th>
                    <td><input type="text" name="title" required></td>
                </tr>
                <tr>
                    <th>Consulta</th>
                    <td><textarea name="query" required></textarea></td>
                </tr>
                <tr>
                    <th>API Key</th>
                    <td><input type="text" name="api_key" required></td>
                </tr>
            </table>
            <input type="submit" name="submit" value="Añadir" class="button add-button">
        </form>

        <h2>Entradas</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Titulo</th>
                    <th>Consulta</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $entries = get_option('widgetgpt_entries', array());
                foreach ($entries as $key => $entry) {
                    $id = $key + 1;
                    echo '<tr>';
                    echo '<td>' . esc_html($id) . '</td>';
                    echo '<td>' . esc_html($entry['title']) . '</td>';
                    echo '<td>' . esc_html($entry['query']) . '</td>';
                    echo '<td>';
                    echo '<button class="button execute-btn" data-id="' . esc_attr($id) . '"><span class="dashicons dashicons-controls-play"></span></button>';
                    echo '<form method="post" style="display:inline;">';
                    echo '<input type="hidden" name="edit_id" value="' . esc_attr($id) . '">';
                    echo '<select name="edit_field">';
                    echo '<option value="title">Titulo</option>';
                    echo '<option value="query">Consulta</option>';
                    echo '</select>';
                    echo '<input type="text" name="edit_value" placeholder="Edita">';
                    echo '<button type="submit" name="edit" class="button"><span class="dashicons dashicons-edit"></span></button>';
                    echo '</form>';
                    echo '<form method="post" style="display:inline;">';
                    echo '<input type="hidden" name="delete_id" value="' . esc_attr($id) . '">';
                    echo '<button type="submit" name="delete_entry" class="button button-danger" onclick="return confirm(\'¿Quieres borra esta consulta?\');"><span class="dashicons dashicons-trash"></span></button>';
                    echo '</form>';
                    echo '</td>';
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
        <form method="post">
            <input type="submit" name="delete_all" value="Borrar Todo" class="button button-danger">
        </form>

        <h2>Respuestas</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Consulta</th>
                    <th>Respuesta</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody id="responses-table">
                <?php
                $responses = get_option('widgetgpt_responses', array());
                foreach ($responses as $response) {
                    echo '<tr>';
                    echo '<td>' . esc_html($response['query']) . '</td>';
                    echo '<td>' . esc_html($response['response']) . '</td>';
                    echo '<td>';
                    echo '<form method="post" style="display:inline;">';
                    echo '<input type="hidden" name="selected_title" value="' . esc_attr($response['title']) . '">';
                    echo '<input type="hidden" name="selected_response" value="' . esc_attr($response['response']) . '">';
                    echo '<button type="submit" name="select_response" class="button"><span class="dashicons dashicons-yes"></span></button>';
                    echo '</form>';
                    echo '<form method="post" style="display:inline;">';
                    echo '<input type="hidden" name="delete_title" value="' . esc_attr($response['title']) . '">';
                    echo '<input type="hidden" name="delete_query" value="' . esc_attr($response['query']) . '">';
                    echo '<input type="hidden" name="delete_response_text" value="' . esc_attr($response['response']) . '">';
                    echo '<button type="submit" name="delete_response" class="button button-danger" onclick="return confirm(\'¿Quieres borrar esta respuesta?\');"><span class="dashicons dashicons-trash"></span></button>';
                    echo '</form>';
                    echo '</td>';
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
    <script>
    jQuery(document).ready(function($) {
        $('.execute-btn').on('click', function() {
            var id = $(this).data('id');
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'widgetgpt_execute',
                    id: id
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert(response.data);
                    }
                },
                error: function() {
                    alert('Error inesperado, lamentamos las molestias');
                }
            });
        });
    });
    </script>
    <?php
}

// AJAX handler for execute
add_action('wp_ajax_widgetgpt_execute', 'widgetgpt_execute_ajax');
function widgetgpt_execute_ajax() {
    $id = intval($_POST['id']);
    $entries = get_option('widgetgpt_entries', array());
    $entry = null;
    foreach ($entries as $key => $e) {
        $current_id = $key + 1;
        if ($current_id == $id) {
            $entry = $e;
            break;
        }
    }
    if ($entry) {
        // Call API (example for OpenAI)
        $api_key = $entry['api_key'];
        $query = $entry['query'];
        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'model' => 'gpt-3.5-turbo',
                'messages' => array(array('role' => 'user', 'content' => $query))
            ))
        ));
        if (!is_wp_error($response)) {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            $reply = $body['choices'][0]['message']['content'];
            $responses = get_option('widgetgpt_responses', array());
            $responses[] = array(
                'title' => $entry['title'],
                'query' => $query,
                'response' => $reply
            );
            update_option('widgetgpt_responses', $responses);
            wp_send_json_success('Response added successfully');
        } else {
            wp_send_json_error('Lamentamos los inconvenientes, fallo de API');
        }
    } else {
        wp_send_json_error('Lamentamos los inconvenientes, fallo de API');
    }
}

// Register widget
add_action('widgets_init', 'widgetgpt_register_widget');
function widgetgpt_register_widget() {
    register_widget('WidgetGPT_Widget');
}

class WidgetGPT_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct(
            'widgetgpt_widget',
            'WidgetGPT',
            array('description' => 'Displays selected GPT response')
        );
    }

    public function widget($args, $instance) {
        $selected = get_option('widgetgpt_selected', array());
        if ($selected && is_array($selected)) {
            echo $args['before_widget'];
            echo $args['before_title'] . esc_html($selected['title']) . $args['after_title'];
            echo '<p>' . esc_html($selected['response']) . '</p>';
            echo $args['after_widget'];
        }
    }

    public function form($instance) {
        // Optional form for widget settings
    }

    public function update($new_instance, $old_instance) {
        $instance = array();
        return $instance;
    }
}
